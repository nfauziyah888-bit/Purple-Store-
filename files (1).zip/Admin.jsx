import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from './supabase'
import { Stars, fmt } from './ui.jsx'

export default function Admin() {
  const [state, setState] = useState('loading'), [email, setEmail] = useState(''), [pw, setPw] = useState('')
  const [rows, setRows] = useState([]), [tab, setTab] = useState('pending'), [err, setErr] = useState(''), [busy, setBusy] = useState('')

  const load = async () => {
    const { data: ok } = await supabase.rpc('is_admin')
    const { data: { session } } = await supabase.auth.getSession()
    if (!session || session.user.is_anonymous) return setState('login')
    if (!ok) return setState('denied')
    const { data, error } = await supabase.from('reviews').select('id,rating,review_text,screenshot_url,status,created_at').order('created_at', { ascending: false })
    if (error) setErr('Gagal memuat data.'); else setRows(data); setState('ok')
  }
  useEffect(() => { load() }, [])

  const login = async e => { e.preventDefault(); setErr('')
    const { error } = await supabase.auth.signInWithPassword({ email, password: pw })
    if (error) setErr('Email atau password salah.'); else { setPw(''); load() } }
  const logout = async () => { await supabase.auth.signOut(); setRows([]); setState('login') }
  const setStatus = async (r, status) => { setBusy(r.id)
    const { error } = await supabase.from('reviews').update({ status }).eq('id', r.id)
    error ? setErr('Gagal mengubah status.') : setRows(rows.map(x => x.id === r.id ? { ...x, status } : x)); setBusy('') }
  const remove = async r => { if (!confirm('Hapus review ini permanen?')) return; setBusy(r.id)
    if (r.screenshot_url) { const p = r.screenshot_url.split('/screenshots/')[1]; if (p) await supabase.storage.from('screenshots').remove([p]) }
    const { error } = await supabase.from('reviews').delete().eq('id', r.id)
    error ? setErr('Gagal menghapus.') : setRows(rows.filter(x => x.id !== r.id)); setBusy('') }

  if (state === 'loading') return <p className="p-10 text-center animate-pulse">Loading…</p>
  if (state !== 'ok') return (<div className="min-h-screen grid place-items-center p-4">
    <form onSubmit={login} className="card p-8 w-full max-w-sm space-y-4">
      <h1 className="font-hand text-4xl text-lav-500 text-center">Admin Login ♡</h1>
      {state === 'denied' && <p className="text-rose-500 text-sm">Akun ini bukan admin. <button type="button" className="underline" onClick={logout}>Logout</button></p>}
      <input type="email" required placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="w-full rounded-2xl border-2 border-lav-100 p-3" />
      <input type="password" required placeholder="Password" value={pw} onChange={e => setPw(e.target.value)} className="w-full rounded-2xl border-2 border-lav-100 p-3" />
      {err && <p role="alert" className="text-sm text-rose-500">{err}</p>}
      <button className="btn w-full">Masuk</button><Link to="/" className="block text-center text-sm underline">Kembali ke toko</Link></form></div>)

  const cnt = s => rows.filter(r => r.status === s).length, list = rows.filter(r => r.status === tab)
  return (<div className="max-w-3xl mx-auto p-4 space-y-5">
    <div className="flex justify-between items-center"><h1 className="font-hand text-4xl text-lav-500">Moderation ♡</h1>
      <div className="flex gap-3 items-center"><Link to="/" className="underline text-sm">Situs</Link><button onClick={logout} className="chip">Logout</button></div></div>
    <p className="text-sm">Total review: <b>{rows.length}</b></p>
    <div className="flex gap-2 flex-wrap">{['pending','approved','rejected'].map(s => <button key={s} onClick={() => setTab(s)} className={`chip ${tab===s?'on':''}`}>{s} ({cnt(s)})</button>)}</div>
    {err && <p role="alert" className="text-rose-500 text-sm">{err}</p>}
    {list.length === 0 && <div className="card p-8 text-center">Tidak ada review di sini ✿</div>}
    {list.map(r => (<div key={r.id} className="card p-5 space-y-3">
      <div className="flex justify-between"><Stars value={r.rating} size="text-lg" /><span className="text-xs">{fmt(r.created_at)}</span></div>
      <p className="whitespace-pre-wrap break-words">{r.review_text}</p>
      {r.screenshot_url && <a href={r.screenshot_url} target="_blank" rel="noreferrer"><img src={r.screenshot_url} alt="Screenshot" className="max-h-60 rounded-2xl border-2 border-lav-100" /></a>}
      <div className="flex gap-2 flex-wrap">
        {r.status !== 'approved' && <button disabled={busy===r.id} onClick={() => setStatus(r,'approved')} className="btn !py-1.5 !px-4 text-sm">Approve</button>}
        {r.status !== 'rejected' && <button disabled={busy===r.id} onClick={() => setStatus(r,'rejected')} className="chip">Reject</button>}
        <button disabled={busy===r.id} onClick={() => remove(r)} className="chip !bg-rose-100 !text-rose-600">Hapus</button></div></div>))}
  </div>)
}
