-- PURPLE STORE: jalankan seluruh file ini di Supabase > SQL Editor
create table public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.admins enable row level security;  -- tanpa policy = tidak bisa diakses lewat API

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path = public
as $$ select exists (select 1 from public.admins where user_id = auth.uid()) $$;

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  rating integer not null check (rating between 1 and 5),
  review_text text not null check (char_length(btrim(review_text)) between 5 and 500),
  screenshot_url text check (screenshot_url is null or screenshot_url like '%/storage/v1/object/public/screenshots/%'),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  submitter_id uuid default auth.uid(),   -- id sesi anonim (bukan data pribadi), untuk rate limit; tidak bisa dibaca publik
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.reviews (status, created_at desc);
alter table public.reviews enable row level security;

-- Hak akses kolom (submitter_id tidak pernah terbaca dari frontend)
revoke all on public.reviews from anon, authenticated;
grant select (id, rating, review_text, screenshot_url, status, created_at, updated_at) on public.reviews to anon, authenticated;
grant insert (rating, review_text, screenshot_url) on public.reviews to authenticated;
grant update (status) on public.reviews to authenticated;
grant delete on public.reviews to authenticated;

-- Kebijakan RLS
create policy "public read approved" on public.reviews for select to anon, authenticated
  using (status = 'approved' or public.is_admin());
create policy "anonymous insert pending" on public.reviews for insert to authenticated
  with check (coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false) and status = 'pending');
create policy "admin update" on public.reviews for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy "admin delete" on public.reviews for delete to authenticated using (public.is_admin());

-- Rate limit (maks 3 review/jam per sesi) + updated_at otomatis
create or replace function public.reviews_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if (select count(*) from public.reviews where submitter_id = new.submitter_id and created_at > now() - interval '1 hour') >= 3
      then raise exception 'Too many reviews'; end if;
    new.status := 'pending';
  end if;
  new.updated_at := now(); return new;
end $$;
create trigger reviews_guard_trg before insert or update on public.reviews for each row execute function public.reviews_guard();

-- Storage: bucket publik, maks 5MB, hanya JPG/PNG/WEBP
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('screenshots','screenshots', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

create policy "anon upload own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'screenshots' and coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false)
              and (storage.foldername(name))[1] = auth.uid()::text);
create policy "admin delete screenshots" on storage.objects for delete to authenticated
  using (bucket_id = 'screenshots' and public.is_admin());

-- Setelah membuat user admin di Authentication > Users, jalankan (ganti emailnya):
-- insert into public.admins (user_id) select id from auth.users where email = 'admin@emailkamu.com';
