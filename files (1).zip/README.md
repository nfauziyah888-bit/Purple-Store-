# PURPLE STORE ♡ — Upload Cepat (GitHub + Netlify)

**Upload semua file ini ke GitHub, dengan struktur folder yang sama** (`src/` dan `supabase/` harus tetap folder):
`package.json`, `index.html`, `netlify.toml`, `vite.config.js`, `tailwind.config.js`, `postcss.config.js`, `.gitignore`, `.env.example`, `README.md`, `src/` (6 file), `supabase/schema.sql`

## Via browser (tanpa Git)
1. github.com → **New repository** → nama `purple-store` → **Create repository**.
2. Klik **uploading an existing file** → drag SEMUA isi folder (termasuk folder `src` dan `supabase`) → **Commit changes**.

## Via terminal
```
git init
git add .
git commit -m "PURPLE STORE"
git branch -M main
git remote add origin https://github.com/USERNAME/purple-store.git
git push -u origin main
```

## Netlify
1. **Add new site → Import from Git** → pilih repo `purple-store`.
2. Isi **Environment variables**: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_TURNSTILE_SITE_KEY` (nilainya dari langkah Supabase/Turnstile di bawah).
3. **Deploy**. Kalau env diisi setelah deploy, pilih **Trigger deploy → Clear cache and deploy site**.

---


## 1. Supabase
1. Daftar di supabase.com → **New project** (simpan database password).
2. **SQL Editor** → New query → tempel seluruh isi `supabase/schema.sql` → **Run**.
3. **Authentication → Sign In / Providers**: aktifkan **Allow anonymous sign-ins** (dipakai pengunjung untuk mengirim review tanpa login).
4. **Authentication → Users → Add user**: buat akun admin (email + password, centang Auto Confirm). Lalu di SQL Editor jalankan baris `insert into public.admins ...` (paling bawah schema.sql) dengan email admin tadi.
5. **Authentication → Sign In / Providers → Email**: matikan **Allow new users to sign up** (supaya orang lain tidak bisa mendaftar).
6. **Project Settings → API**: salin **Project URL** dan **anon public key** (aman ada di frontend; JANGAN pernah memakai service_role key).

## 2. CAPTCHA (Cloudflare Turnstile, gratis)
1. dash.cloudflare.com → **Turnstile → Add widget**, isi domain Netlify kamu (dan `localhost`). Salin **Site Key** dan **Secret Key**.
2. Supabase → **Authentication → Attack Protection** → aktifkan CAPTCHA, pilih Turnstile, tempel **Secret Key**.
3. Site Key dipakai di Netlify (langkah 4). Secret Key hanya disimpan di Supabase.
4. Rate limit: Supabase membatasi anonymous sign-in per IP (Authentication → Rate Limits), dan database membatasi 3 review/jam per sesi.

## 3. Jalankan lokal (opsional)
```
npm install
cp .env.example .env   # isi 3 nilainya
npm run dev
```

## 4. Deploy Netlify
1. Upload folder ini ke GitHub (`.env` otomatis diabaikan oleh `.gitignore`).
2. Netlify → **Add new site → Import from Git** → pilih repo. Build command `npm run build`, publish dir `dist` (sudah di `netlify.toml`, termasuk redirect agar `/admin` tidak 404 saat refresh).
3. **Site configuration → Environment variables**, tambahkan: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_TURNSTILE_SITE_KEY`.
4. **Deploys → Trigger deploy**. Selesai!
5. Supabase → **Authentication → URL Configuration**: isi Site URL dengan URL Netlify kamu.

## 5. Cara pakai
- Admin: buka `/admin`, login, lalu Approve / Reject / Hapus. Review baru selalu `pending`.
- Catatan: login admin di browser yang sama akan menggantikan sesi pengunjung; logout dulu kalau mau mengetes form sebagai customer.
- Bucket gambar bersifat publik (URL acak tidak mudah ditebak); screenshot yang di-reject tetap ada sampai kamu hapus review-nya.
