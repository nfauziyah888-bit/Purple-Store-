import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from './supabase'
import { Stars, Avatar, fmt, Sparkles } from './ui.jsx'

const SITE = import.meta.env.VITE_TURNSTILE_SITE_KEY
const TYPES = { 'image/jpeg':'jpg', 'image/png':'png', 'image/webp':'webp' }

function Form({ onDone }) {
  const [rating, setRating] = useState(0), [text, setText] = useState(''), [file, setFile] = useState(null)
  const [agree, setAgree] = useState(false), [token, setToken] = useState(''), [err, setErr] = useState('')
  const [sending, setSending] = useState(false), [sent, setSent] = useState(false)
  const lock = useRef(false), cap = useRef(), wid = useRef()
  const preview = useMemo(() => file && URL.createObjectURL(file), [file])

  useEffect(() => {
    if (!SITE) return
    const t = setInterval(() => { if (window.turnstile && cap.current) { clearInterval(t)
      wid.current = window.turnstile.render(cap.current, { sitekey: SITE, callback: setToken, 'expired-callback': () => setToken('') }) } }, 300)
    return () => clearInterval(t)
  }, [])

  const pick = e => {
    const f = e.target.files[0]; setErr('')
    if (!f) return setFile(null)
    if (!TYPES[f.type]) { setErr('Format harus JPG, PNG, atau WEBP.'); e.target.value=''; return }
    if (f.size > 5 * 1024 * 1024) { setErr('Ukuran gambar maksimal 5 MB.'); e.target.value=''; return }
    setFile(f)
  }

  const submit = async e => {
    e.preventDefault()
    if (lock.current) return
    const t = text.trim()
    if (!rating) return setErr('Pilih rating bintang dulu ya ♡')
    if (t.length < 5 || t.length > 500) return setErr('Review harus 5–500 karakter.')
    if (!agree) return setErr('Centang persetujuan dulu ya.')
    if (SITE && !token) return setErr('Selesaikan verifikasi CAPTCHA dulu ya.')
    lock.current = true; setSending(true); setErr('')
    try {
      let { data: { session } } = await supabase.auth.getSession()
      if (!session?.user?.is_anonymous) {
        const { data, error } = await supabase.auth.signInAnonymously({ options: { captchaToken: token || undefined } })
        if (error) throw error; session = data.session
      }
      let screenshot_url = null
      if (file) {
        const path = `${session.user.id}/${crypto.randomUUID()}.${TYPES[file.type]}`
        const { error } = await supabase.storage.from('screenshots').upload(path, file, { contentType: file.type })
        if (error) throw error
        screenshot_url = supabase.storage.from('screenshots').getPublicUrl(path).data.publicUrl
      }
      const { error } = await supabase.from('reviews').insert({ rating, review_text: t, screenshot_url })
      if (error) throw error
      setSent(true); onDone?.()
    } catch (x) {
      setErr(/Too many/i.test(x.message) ? 'Kamu sudah terlalu sering mengirim. Coba lagi nanti ya ♡' : 'Gagal mengirim. Coba lagi sebentar lagi ya.')
      if (window.turnstile && wid.current !== undefined) window.turnstile.reset(wid.current); setToken('')
    } finally { setSending(false); lock.current = false }
  }

  if (sent) return <div className="card p-8 text-center animate-pop"><div className="text-5xl mb-3">🎀</div>
    <p className="text-lg">Yay! Your sweet review has been sent! 🎀 Thank you for supporting Purple Store. Your review will appear after approval. ♡</p></div>

  return (
    <form onSubmit={submit} className="card p-6 sm:p-8 space-y-5">
      <div><p className="font-semibold mb-1">Rating kamu ✿</p><Stars value={rating} onChange={setRating} size="text-4xl" /></div>
      <div><label className="font-semibold block mb-1" htmlFor="rv">Review kamu</label>
        <textarea id="rv" value={text} maxLength={500} rows={4} onChange={e => setText(e.target.value)}
          placeholder="Tulis pengalaman belanja kamu di Purple Store yuk! 🧸💌"
          className="w-full rounded-2xl border-2 border-lav-100 bg-cream p-3 focus:outline-none focus:border-lav-500" />
        <p className="text-right text-xs text-lav-700">{text.length}/500</p></div>
      <div><p className="font-semibold">Screenshot (opsional) ✧</p>
        <p className="text-sm text-lav-700 mb-2">JPG/PNG/WEBP, maks 5 MB. Sensor dulu data pribadi (nama, nomor, email, alamat) ya!</p>
        <input type="file" accept="image/jpeg,image/png,image/webp" onChange={pick} className="text-sm" />
        {preview && <img src={preview} alt="Preview" className="mt-3 max-h-48 rounded-2xl border-2 border-lav-100" />}</div>
      <label className="flex gap-2 items-start text-sm"><input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} className="mt-1 accent-lav-500" />
        Aku setuju review dan gambar ini ditampilkan secara publik.</label>
      {SITE && <div ref={cap} />}
      {err && <p role="alert" className="text-sm text-rose-500">{err}</p>}
      <button className="btn w-full sm:w-auto" disabled={sending}>{sending ? 'Sending… ✧' : 'Send My Love Note ♡'}</button>
    </form>)
}

function Reviews({ refreshKey }) {
  const [rows, setRows] = useState(null), [err, setErr] = useState(''), [flt, setFlt] = useState(0), [asc, setAsc] = useState(false)
  useEffect(() => { supabase.from('reviews').select('id,rating,review_text,screenshot_url,created_at').eq('status','approved')
    .then(({ data, error }) => error ? setErr('Gagal memuat review.') : setRows(data)) }, [refreshKey])
  if (err) return <p className="text-center text-rose-500">{err}</p>
  if (!rows) return <p className="text-center animate-pulse">Loading love notes… ♡</p>
  const avg = rows.length ? (rows.reduce((a, r) => a + r.rating, 0) / rows.length).toFixed(1) : '–'
  const list = rows.filter(r => !flt || r.rating === flt).sort((a, b) => (asc ? 1 : -1) * (new Date(a.created_at) - new Date(b.created_at)))
  return (<div className="space-y-5">
    <div className="card p-5 flex flex-wrap gap-6 justify-center text-center">
      <div><p className="text-3xl font-semibold">{rows.length}</p><p className="text-sm">review</p></div>
      <div><p className="text-3xl font-semibold">{avg} <span className="text-amber-400">★</span></p><p className="text-sm">rata-rata rating</p></div></div>
    <div className="flex flex-wrap gap-2 justify-center">
      {[0,5,4,3,2,1].map(n => <button key={n} onClick={() => setFlt(n)} className={`chip ${flt===n?'on':''}`}>{n ? `${n} ★` : 'Semua'}</button>)}
      <button onClick={() => setAsc(!asc)} className="chip">{asc ? 'Terlama ↑' : 'Terbaru ↓'}</button></div>
    {list.length === 0 ? <div className="card p-10 text-center"><div className="text-4xl">💌</div>
      <p className="mt-2">{rows.length ? 'Belum ada review untuk rating ini.' : 'Belum ada review. Jadilah yang pertama menulis love note ♡'}</p></div>
    : <div className="grid gap-4 sm:grid-cols-2">{list.map(r => (
      <article key={r.id} className="card p-5 space-y-3 animate-pop">
        <div className="flex items-center gap-3"><Avatar id={r.id} /><div><p className="font-semibold">Lovely Customer ♡</p><Stars value={r.rating} size="text-lg" /></div></div>
        <p className="whitespace-pre-wrap break-words">{r.review_text}</p>
        {r.screenshot_url && <a href={r.screenshot_url} target="_blank" rel="noreferrer"><img loading="lazy" src={r.screenshot_url} alt="Screenshot customer" className="rounded-2xl border-2 border-lav-100 max-h-60 w-full object-cover" /></a>}
        <p className="text-xs text-lav-700">{fmt(r.created_at)}</p></article>))}</div>}
  </div>)
}

export default function Home() {
  const [k, setK] = useState(0)
  return (<div className="min-h-screen relative"><Sparkles />
    <header className="relative z-10 text-center pt-8 pb-4 px-4">
      <p className="font-semibold tracking-wide text-lav-700">PURPLE STORE ♡</p>
      <h1 className="font-hand text-5xl sm:text-6xl text-lav-500 mt-2">Sweet Words From You ୨୧</h1>
      <p className="mt-2">"Your little review means so much to us! ♡"</p></header>
    <main className="relative z-10 max-w-3xl mx-auto px-4 pb-16 space-y-10">
      <Form onDone={() => setK(k + 1)} /><Reviews refreshKey={k} /></main>
    <footer className="relative z-10 text-center pb-6 text-xs text-lav-700"><Link to="/admin">admin</Link></footer></div>)
}
