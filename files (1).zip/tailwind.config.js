export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: { lav: { 100:'#EEE6FB', 300:'#CDB8F2', 500:'#9C7BD9', 700:'#6B4BA8' }, blush:'#FFD6E4', peach:'#FFD9BF', cream:'#FFF8EE', ink:'#4A3B63' },
    fontFamily: { cute:['Fredoka','sans-serif'], hand:['Caveat','cursive'] },
    boxShadow: { soft:'0 10px 30px -10px rgba(156,123,217,.35)' },
    keyframes: { float:{ '0%,100%':{transform:'translateY(0) rotate(0)'}, '50%':{transform:'translateY(-8px) rotate(6deg)'} }, pop:{ '0%':{transform:'scale(.6)',opacity:0}, '100%':{transform:'scale(1)',opacity:1} } },
    animation: { float:'float 5s ease-in-out infinite', pop:'pop .4s ease-out' } } },
  plugins: [] }
