export const Stars = ({ value = 0, onChange, size = 'text-3xl' }) => (
  <div className="flex gap-1" role={onChange ? 'radiogroup' : 'img'} aria-label={`Rating ${value} dari 5`}>
    {[1,2,3,4,5].map(n => (
      <button key={n} type="button" disabled={!onChange} onClick={() => onChange?.(n)} aria-label={`${n} bintang`}
        className={`${size} leading-none transition hover:scale-125 ${n <= value ? (value>=4?'text-amber-400':value===3?'text-orange-300':'text-pink-400') : 'text-lav-300'}`}>
        {n <= value ? '★' : '☆'}</button>))}
  </div>)
const AV = ['🐰','🐻','🐱','🦊','🐼','🐥','🦄','🐹']
export const Avatar = ({ id }) => {
  const i = [...id].reduce((a, c) => a + c.charCodeAt(0), 0) % AV.length
  return <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blush to-peach grid place-items-center text-2xl shadow-soft">{AV[i]}</div>
}
export const fmt = d => new Date(d).toLocaleDateString('id-ID', { day:'numeric', month:'long', year:'numeric' })
export const Sparkles = () => (
  <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden -z-0 opacity-70">
    {[['✦','8%','12%'],['✿','88%','18%'],['★','5%','60%'],['🎀','92%','70%'],['✧','50%','5%']].map(([s,l,t],i)=>(
      <span key={i} className="absolute text-2xl text-lav-300 animate-float" style={{left:l,top:t,animationDelay:`${i}s`}}>{s}</span>))}
  </div>)
