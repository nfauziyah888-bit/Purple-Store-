import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './Home.jsx'
import Admin from './Admin.jsx'
import './index.css'
createRoot(document.getElementById('root')).render(
  <BrowserRouter><Routes>
    <Route path="/" element={<Home />} /><Route path="/admin" element={<Admin />} />
    <Route path="*" element={<p className="p-10 text-center">Halaman tidak ditemukan ♡ <Link className="underline" to="/">Kembali</Link></p>} />
  </Routes></BrowserRouter>)
